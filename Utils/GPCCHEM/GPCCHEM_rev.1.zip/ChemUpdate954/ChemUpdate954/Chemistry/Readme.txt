--------------------------------------------------
The information and data provided herein are
provided exclusively for use with TI BQStudio
software and are subject to the terms of the
applicable TI license agreement for the TI 
BQStudio software suite.

Your use of this information and data acknowledges
your agreement to those BQStudio license terms.
--------------------------------------------------